# Convert the given text to speech

# pip install nltk
# pip install gtts
# pip install --upgrade wheel
# pip install playsound

from gtts import gTTS
from playsound import playsound

mytext = "Hello World"
lang = "en"

myobj = gTTS(text = mytext, lang = lang, slow = False)

myobj.save("./myFile.mp3")

playsound("./myFile.mp3")