# Study Default Tagger 
import nltk
nltk.download('treebank')
from nltk.tag import DefaultTagger
from nltk.corpus import treebank
exptagger = DefaultTagger("NN")
testsentences=treebank.tagged_sents()[1000:]
print(exptagger.accuracy(testsentences))
print(exptagger.tag_sents([['Hey',','],['How', 'are', 'you','?']]))
