# Study PorterStemmer, LancasterStemmer, RegexpStemmer, SnowballStemmer Study WordNetLemmatizer

import nltk
nltk.download("wordnet")
word = "running"
print("PoterStemmer")
from nltk.stem import PorterStemmer
word_stemmer = PorterStemmer()
print(word_stemmer.stem(word))

print("---------------------------------")
print("Lancaster Stemmer")
from nltk.stem import LancasterStemmer
Lanc_stemmer = LancasterStemmer()
print(Lanc_stemmer.stem(word))

print("---------------------------------")
print('RegexpStemmer')
import nltk
from nltk.stem import RegexpStemmer
Reg_stemmer = RegexpStemmer('ing$|s$|e$|able$', min=4)
print(Reg_stemmer.stem(word))

print("---------------------------------")
print('SnowballStemmer')
from nltk.stem import SnowballStemmer
english_stemmer = SnowballStemmer('english')
print(english_stemmer.stem (word))

print("---------------------------------")
print('WordNetLemmatizer')
from nltk.stem import WordNetLemmatizer
lemmatizer = WordNetLemmatizer()
print("word :\tlemma")
print("rocks :", lemmatizer.lemmatize("rocks"))
print("corpora :", lemmatizer.lemmatize("corpora"))

print("better :", lemmatizer.lemmatize("better", pos ="a"))
