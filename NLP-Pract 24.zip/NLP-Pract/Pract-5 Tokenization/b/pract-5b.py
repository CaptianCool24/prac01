# Tokenization using Regular Expressions (RegEx)
import nltk
from nltk.tokenize import RegexpTokenizer
tk = RegexpTokenizer('\s+',gaps = True)
str = "Let's use RegexpTokenizer to split"
tokens = tk.tokenize(str)
print(tokens)
