import nltk
from nltk.tokenize import word_tokenize

# Create a string input
str = "Let's use word_tokenize to split"

# Use tokenize method
print(word_tokenize(str))
