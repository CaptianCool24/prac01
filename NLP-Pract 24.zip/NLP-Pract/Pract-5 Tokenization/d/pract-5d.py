import spacy
nlp = spacy.blank("en")
# Create a string input
str = "Let's use spacy to split"
# Create an instance of document;
# doc object is a container for a sequence of Token objects.
doc = nlp(str)
# Read the words; Print the words
#
words = [word.text for word in doc]
print(words)
