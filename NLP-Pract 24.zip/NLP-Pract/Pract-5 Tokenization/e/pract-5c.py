# pip install tensorflow
# pip install keras
# pip install Keras-Preprocessing
import keras
from keras.preprocessing.text import text_to_word_sequence
# Create a string input
str = "Let's use keras to split"
# tokenizing the text
tokens = text_to_word_sequence(str)
print(tokens)
