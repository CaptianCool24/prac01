# Compare two nouns

import nltk
from nltk.corpus import wordnet
syn1 = wordnet.synsets("cricket")
syn2 = wordnet.synsets("hokey")
for s1 in syn1:
    for s2 in syn2:
        print("Path similarity of: ")
        print(s1, "(",s1.pos(),")","[",s1.definition(),"]")
        print(s1, "(",s2.pos(),")","[",s2.definition(),"]")
        print("is", s1.path_similarity(s2))
