# Create and use your own corpora (plaintext, categorical)

import nltk 
nltk.download("punkt")

from nltk.corpus import PlaintextCorpusReader

corpus_root = "./user-defined-corpus-txt"
fileList = PlaintextCorpusReader(corpus_root, ".*")
print ("\n File List \n")
print(fileList.fileids())

print(fileList.root)

print("\n\n Statistics for each text:\n")
print("Avg_Word_Len\tAvg_Sentence_Len\tno._of_Times_Each_Word_Appears_On_Avg\tFile_Name")

for fileid in fileList.fileids():
    num_chars = len(fileList.raw(fileid))
    num_words = len(fileList.words(fileid))
    num_sents = len(fileList.sents(fileid))
    num_vocab = len(set([w.lower() for w in fileList.words(fileid)]))

    print(int(num_chars/num_words),"\t\t\t",int(num_words/num_sents),"\t\t\t",int(num_words/num_vocab),"\t\t\t",fileid)